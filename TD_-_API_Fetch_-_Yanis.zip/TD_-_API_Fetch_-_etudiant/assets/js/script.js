function getStarsFromVote(score) {
    score = parseInt(score+0.5)/2;
    container = document.createElement("div");
    let n_fill = parseInt(score);
    let n_half = parseInt(score-n_fill+0.5);
    for (let i = 0; i < 5; i++) {
        let star = document.createElement("i");
        if (i < n_fill) {star.classList.add("fa-solid", "fa-star");}
        else if (i < n_fill+n_half) {star.classList.add("fa-solid", "fa-star-half-stroke");}
        else {star.classList.add("fa-regular", "fa-star");}
        container.append(star);
    }
    return container.innerHTML;
}

function getArticle(movie){
    let container = document.createElement("div")
    container.className = "col-12 col-md-4 col-lg-3"
    let description = movie.overview;
    container.innerHTML = `
        <article class="card mb-3 border-0 ">
            <div class="row g-0 bg-secondary">
                <div class="col-md-4">
                    <img src="${movie.poster_path}" class="img-fluid"></img>
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title text-black text-center">${movie.original_title}</h5>
                        <p class="card-text text-black">${description}</p>
                        <p class="card-text stars"><small class="text-muted">${getStarsFromVote(movie.vote_average)}</small></p>
                    </div>
                </div>
            </div>
        </article>
        `;
    return container
}

fetch(new Request("assets/data/movies.json"))
    .then((result) => result.json())
    .then((result) => {
        console.log("abc")
        let movies_container = document.getElementById("movies-container");
        movies = result.results.map(getArticle);
        for (i of movies) {movies_container.append(i);}
    })